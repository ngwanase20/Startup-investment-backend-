import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const Signup = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const navigate = useNavigate()

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    const res = await fetch('http://localhost:4000/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    if (res.ok) navigate('/login')
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto p-6">
      <h2 className="text-2xl mb-4">Sign Up</h2>
      <input name="name" placeholder="Name" onChange={handleChange} className="block w-full mb-2 p-2 border" required />
      <input name="email" type="email" placeholder="Email" onChange={handleChange} className="block w-full mb-2 p-2 border" required />
      <input name="password" type="password" placeholder="Password" onChange={handleChange} className="block w-full mb-4 p-2 border" required />
      <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Sign Up</button>
    </form>
  )
}

export default Signup
