import React, { useEffect, useState } from 'react'

const Dashboard = () => {
  const [startups, setStartups] = useState([])

  useEffect(() => {
    const fetchStartups = async () => {
      const res = await fetch('http://localhost:4000/api/startups')
      const data = await res.json()
      setStartups(data)
    }
    fetchStartups()
  }, [])

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Available Startups</h2>
      <div className="grid gap-4">
        {startups.map(s => (
          <div key={s.id} className="p-4 border rounded shadow">
            <h3 className="text-xl">{s.name}</h3>
            <p>{s.description}</p>
            <p>Goal: ${s.fundingGoal.toLocaleString()}</p>
            <p>Raised: ${s.currentFunding.toLocaleString()}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Dashboard
