import React from 'react'
import { Link } from 'react-router-dom'

const App = () => (
  <div className="p-6 text-center">
    <h1 className="text-4xl font-bold mb-4">Invest in Startups</h1>
    <p className="mb-4">Join the platform that connects investors with the most promising startups.</p>
    <Link to="/signup" className="bg-blue-600 text-white px-4 py-2 rounded">Get Started</Link>
  </div>
)

export default App
